from pathlib import Path
import sqlite3
import pandas as pd

ROOT = Path(__file__).resolve().parent

# เชื่อมต่อฐานข้อมูลโดยตรง
with sqlite3.connect(ROOT / 'data' / 'warehouse.db') as con:
    df = pd.read_sql_query('SELECT * FROM sales', con)

# P1: province x month
p1 = df.pivot_table(
    index='province',
    columns='month',
    values='amount',
    aggfunc='sum',
    fill_value=0,
    margins=True,
    margins_name='Total'
)
print("--- P1: Province x Month ---")
print(p1)

# P2: September category x province
df_sep = df[df['month'] == '2026-09']
p2 = df_sep.pivot_table(
    index='category',
    columns='province',
    values='amount',
    aggfunc='sum',
    fill_value=0
)
print("\n--- P2: Category x Province (Sept) ---")
print(p2)

# P3: Assert Grand Total
assert p1.loc['Total', 'Total'] == df['amount'].sum(), "Grand Total Mismatch!"

# P4: Export CSV
p1.to_csv('pivot_province_month.csv')
p2.to_csv('pivot_september.csv')
print("\nExported pivot CSVs successfully!")