SELECT 
    s.store_name, 
    SUM(f.quantity * f.unit_price) AS total_revenue, 
    ROUND(CAST(SUM(f.quantity * f.unit_price) AS FLOAT) / COUNT(DISTINCT f.order_id), 2) AS aov 
FROM fact_sales f 
JOIN dim_store s ON f.store_key = s.store_key 
GROUP BY s.store_name 
ORDER BY total_revenue DESC 
LIMIT 3;