SELECT 
    d.month, 
    ROUND(CAST(SUM(f.quantity * f.unit_price) AS FLOAT) / COUNT(DISTINCT f.order_id), 2) AS monthly_aov 
FROM fact_sales f 
JOIN dim_date d ON f.date_key = d.date_key 
GROUP BY d.month 
ORDER BY d.month;